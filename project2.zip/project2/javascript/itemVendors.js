"use strict";
window.onload = getData;

function getData(){
    const API_KEY = "5315645902fe4f84934a39be6b672cff";
    let url = "http://cors-anywhere.herokuapp.com/https://www.bungie.net/Platform/";
    let xhr = new XMLHttpRequest();
    const displayName = "KaZR";
    const membershipType = "3";
    url += `Destiny2/SearchDestinyPlayer/${membershipType}/${displayName}`;
    //url += "Destiny2/Manifest/";
    
    xhr.open("GET", url);
    xhr.setRequestHeader("X-API-KEY", API_KEY);
    
    xhr.send(null);

    // $.ajax({
    //     dataType: "json",
    //     url: url,
    //     success: dataLoaded,
    //     error: dataError,
    //     Headers: {"X-API-Key":API_KEY}
    // });
}

function dataLoaded(e){
    let xhr = e.target;

    console.log(xhr.responseText);
    document.querySelector("#response").innerHTML = xhr.responseText;
}

function dataError(){
    console.log("An error occurred");
}